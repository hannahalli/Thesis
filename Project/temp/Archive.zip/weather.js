// Constants for the screen dimensions
const SCREEN_WIDTH = 1536;
const SCREEN_HEIGHT = 868;

// Get canvas context
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

// Function to calculate the current position of the sun
function calculateSunPosition(sunrise, sunset) {
    const now = new Date();
    const totalDaytime = sunset - sunrise;
    const currentTime = now - sunrise;
    const progress = currentTime / totalDaytime;
    const sunX = SCREEN_WIDTH / 2; // Centered horizontally
    const sunY = SCREEN_HEIGHT * (1 - progress); // Moves from bottom to top
    return { x: sunX, y: sunY };
}

// Fetch sunrise and sunset times using an API
async function getSunriseSunset() {
    // You may need to replace 'YOUR_LATITUDE' and 'YOUR_LONGITUDE' with actual coordinates
    const response = await fetch(`https://api.sunrise-sunset.org/json?lat=42.3893679&lng=-72.528655&formatted=0`);
    const data = await response.json();
    const sunrise = new Date(data.results.sunrise);
    const sunset = new Date(data.results.sunset);
    return { sunrise, sunset };
}

// Main animation loop
async function animateSun() {
    const { sunrise, sunset } = await getSunriseSunset();

    // Clear canvas
    ctx.clearRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

    // Calculate sun position based on current time
    const { x, y } = calculateSunPosition(sunrise, sunset);

    // Draw the sun image
    const sunImg = new Image();
    sunImg.onload = function () {
        ctx.drawImage(sunImg, x - sunImg.width / 2, y - sunImg.height / 2);
    };
    sunImg.src = 'sun.png';

    // Request next frame
    requestAnimationFrame(animateSun);
}

// Start the animation
animateSun();
