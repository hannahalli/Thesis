(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"backgroud_1_atlas_1", frames: [[0,0,1755,1675]]},
		{name:"backgroud_1_atlas_2", frames: [[0,0,1468,1629]]},
		{name:"backgroud_1_atlas_3", frames: [[0,0,1136,1966]]},
		{name:"backgroud_1_atlas_4", frames: [[1099,0,816,1798],[0,0,1097,1398]]},
		{name:"backgroud_1_atlas_5", frames: [[957,0,771,1858],[0,0,955,1506]]},
		{name:"backgroud_1_atlas_6", frames: [[0,0,1960,597],[0,599,762,1298]]},
		{name:"backgroud_1_atlas_7", frames: [[1412,0,462,1373],[0,0,497,1567],[0,1569,1410,450]]},
		{name:"backgroud_1_atlas_8", frames: [[0,543,1644,355],[0,0,1129,541],[0,900,1056,522],[0,1424,1264,436]]},
		{name:"backgroud_1_atlas_9", frames: [[411,545,329,290],[411,837,227,331],[773,1062,99,227],[0,1258,471,450],[0,1877,144,107],[198,1956,139,68],[146,1956,18,16],[0,1986,196,56],[0,0,878,543],[146,1877,144,77],[640,837,189,223],[880,0,264,1454],[473,1354,307,117],[473,1170,298,182],[146,1974,5,1],[640,1062,130,82],[0,1710,611,165],[0,545,409,711]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_51 = function() {
	this.initialize(ss["backgroud_1_atlas_5"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_50 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_49 = function() {
	this.initialize(ss["backgroud_1_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_48 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_47 = function() {
	this.initialize(ss["backgroud_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_46 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_45 = function() {
	this.initialize(ss["backgroud_1_atlas_7"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_44 = function() {
	this.initialize(img.CachedBmp_44);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1529,3463);


(lib.CachedBmp_43 = function() {
	this.initialize(img.CachedBmp_43);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,883,3116);


(lib.CachedBmp_42 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_41 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_40 = function() {
	this.initialize(ss["backgroud_1_atlas_6"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_39 = function() {
	this.initialize(ss["backgroud_1_atlas_8"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(img.CachedBmp_38);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2523,993);


(lib.CachedBmp_37 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["backgroud_1_atlas_5"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(img.CachedBmp_34);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2342,868);


(lib.CachedBmp_33 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_32 = function() {
	this.initialize(ss["backgroud_1_atlas_8"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["backgroud_1_atlas_8"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["backgroud_1_atlas_7"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_24 = function() {
	this.initialize(ss["backgroud_1_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_20 = function() {
	this.initialize(img.CachedBmp_20);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2490,1711);


(lib.CachedBmp_19 = function() {
	this.initialize(ss["backgroud_1_atlas_8"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["backgroud_1_atlas_4"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["backgroud_1_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(ss["backgroud_1_atlas_6"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["backgroud_1_atlas_9"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["backgroud_1_atlas_7"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.tree8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_51();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_50();
	this.instance_1.setTransform(66,209.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,385.5,929);


(lib.tree7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_49();
	this.instance.setTransform(0,0,0.4562,0.4562);

	this.instance_1 = new lib.CachedBmp_48();
	this.instance_1.setTransform(394.8,161.05,0.4562,0.4562);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,669.7,743.1);


(lib.tree6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5C4033").s().p("AhFgqQgYgnAEgZQADgSAQgKQARgKAOAIIgwAdQAsBnBaBbQAUAVAYAVIAAAMQhkhYg8hfg");
	this.shape.setTransform(26.9964,86.7474);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.CachedBmp_47();
	this.instance.setTransform(0,0,0.4498,0.4498);

	this.instance_1 = new lib.CachedBmp_46();
	this.instance_1.setTransform(137.65,509.15,0.4498,0.4498);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,789.4,753.4);


(lib.tree5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_45();
	this.instance.setTransform(0,0,0.4498,0.4498);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,207.8,617.6);


(lib.tree3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_44();
	this.instance.setTransform(0,0,0.3929,0.3929);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,600.8,1360.6);


(lib.tree2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_43();
	this.instance.setTransform(209.3,379.05,0.2189,0.2189);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(209.3,379.1,193.3,681.9999999999999);


(lib.SUn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_15
	this.instance = new lib.CachedBmp_42();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,235.5,225);


(lib.bush = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_41();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,72,53.5);


// stage content:
(lib.RECOVER_backgroud = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_24
	this.instance = new lib.CachedBmp_13();
	this.instance.setTransform(764.9,657.65,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_9
	this.instance_1 = new lib.tree3("synched",0);
	this.instance_1.setTransform(1264.2,488.05,1.2726,1,0,0,180,300.4,680.2);

	this.instance_2 = new lib.CachedBmp_14();
	this.instance_2.setTransform(1107.65,202,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(1));

	// Layer_3
	this.instance_3 = new lib.CachedBmp_16();
	this.instance_3.setTransform(-40.5,-73.35,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_15();
	this.instance_4.setTransform(-73.9,107.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3}]}).wait(1));

	// Layer_28
	this.instance_5 = new lib.CachedBmp_17();
	this.instance_5.setTransform(226.45,672.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// Layer_8
	this.instance_6 = new lib.CachedBmp_19();
	this.instance_6.setTransform(286.5,732.65,0.5,0.5);

	this.instance_7 = new lib.tree2("synched",0);
	this.instance_7.setTransform(1011.75,171,2.2844,2.0677,0,0.6482,-179.0826,394.6,766.2);

	this.instance_8 = new lib.CachedBmp_18();
	this.instance_8.setTransform(940.95,-360.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8},{t:this.instance_7},{t:this.instance_6}]}).wait(1));

	// MergedLayer_4
	this.instance_9 = new lib.tree6("synched",0);
	this.instance_9.setTransform(549.1,371.2,1,1.1116,0,0,0,394.8,410.9);

	this.instance_10 = new lib.CachedBmp_20();
	this.instance_10.setTransform(-318.3,-75.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9}]}).wait(1));

	// Layer_34
	this.instance_11 = new lib.CachedBmp_21();
	this.instance_11.setTransform(176.45,635.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(1));

	// MergedLayer_2
	this.instance_12 = new lib.tree5("synched",0);
	this.instance_12.setTransform(177.45,329.6,0.6935,1.1116,0,0,0,104.1,308.9);

	this.instance_13 = new lib.CachedBmp_22();
	this.instance_13.setTransform(656.95,645.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_13},{t:this.instance_12}]}).wait(1));

	// Layer_30
	this.instance_14 = new lib.CachedBmp_23();
	this.instance_14.setTransform(590.6,659.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(1));

	// Layer_29
	this.instance_15 = new lib.CachedBmp_24();
	this.instance_15.setTransform(453.2,-21.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(1));

	// Layer_11
	this.instance_16 = new lib.tree7("synched",0);
	this.instance_16.setTransform(618.95,313.85,0.897,1.0961,0,0,0,334.9,371.6);

	this.instance_17 = new lib.CachedBmp_26();
	this.instance_17.setTransform(1423.7,-122.6,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_25();
	this.instance_18.setTransform(461.65,73.65,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_18},{t:this.instance_17},{t:this.instance_16}]}).wait(1));

	// Layer_33
	this.instance_19 = new lib.CachedBmp_27();
	this.instance_19.setTransform(485.15,580.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(1));

	// Layer_20
	this.instance_20 = new lib.CachedBmp_28();
	this.instance_20.setTransform(800.45,684.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(1));

	// Layer_16
	this.instance_21 = new lib.CachedBmp_29();
	this.instance_21.setTransform(843.9,-57.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(1));

	// Layer_15
	this.instance_22 = new lib.tree8("synched",0);
	this.instance_22.setTransform(969.2,235.95,0.8314,1,0,0,0,192.8,464.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#785B35").s().p("AjeClQgMgGgIgMQgIgMACgNQACgUATgOQAOgKAYgHQAOgFAEgDIAOgNQAMgKAVgHIAkgLQAugPAtgoIAGgHIAxg3IAGgHQATgVAIgLQAOgWAHgGQARgLARAHQATAHACAUQABAOgNAVIgHAKQAAAMgIAPQgFAJgJALIgQATQAOgBAMAKQAMAKADAOQAFAcgXAZQgQARgfAQQg4AdgoAEQgTABgHADQgFACgHAEIgMAHQgLAEgVgBQgXgBgJABQgJACgPAIIgXALQgPAFgNAAQgMAAgLgFgADKgyQgEgIADgKQADgKAIgEQAIgFAKACQAKADAFAIQAGAIgCAKQgCAKgIAGQgHAEgJAAQgOgBgHgNg");
	this.shape.setTransform(907.9567,687.149);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#7F9C2D").s().p("AosD3QgDgEgDgIQgQAJgRACIgBAAQgbACgbgPQgcgTgPgHQgVgKgqgDQgvgDgUgEQgkgHgYgRQgkgbgWhEQgPgsAHgcQAGgWAZgcQAgglAdACQATABAOAQQAOAPADAVQAEAZgKAYQgLAZgVAPQACADAFANQAEAKAGABQADABAIgEQALgDAVAEIA0ANQAgAIATADQA2AHAhgUIANgIIAQgQQADgNADgJQANgYAFgNQADgJAHgcQAFgYAHgNIAIgPQAFgJABgHQACgIgBgNIgCgVQgBgVAOglQAIgWAIgMQALgSAQgGQANgGAPAEQAQADAJALQAPARAAAaQAAAagLATIgLARQgCAGABAHIABANQADAhgOAgQgEAKgKATQgGAOgIAcIgMAoIgGAUQgCAMgFAPQgEARgCAYIgGA5IgxA3QgQgDgKgMgALxC+QgVgOAAgZQAAgIADgLIAFgTIACggIACgbQAAgPgCgLIgFgVIgGgTQgGgZAMgOQgggUgNghQgGgSgEgIQgLgSgEgKQgHgRAGgUQAGgTAQgJQANgGATABIAhACIAWAAQAPgBAIABQAcADAMAQQALAMgDATQgCARgNAMQAPgIAQABQARABAMAKQAIAGAJAOIAXAhQAKAPAEAJQAHAOAAAMQgBAQgOAWQgKAQgBAIQAAAHACAMQAAARgVAYIhEBPQgYAegTAFQgIADgIAAQgOAAgNgJg");
	this.shape_1.setTransform(961.9653,656.8819);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,0,0.098)").s().p("AlDLzQg7gEgggrQARADASAAQAeAAA8gEQA2gBAjALIAHACIgTAJQgzAbgxAAIgLAAgAGbqxIABhBQAEAbgBAdIgEAiIAAgZg");
	this.shape_2.setTransform(975.01,718.8683);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_22}]}).wait(1));

	// Layer_12
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#7F9C2D").s().p("AMuMUIgFgEQAAABAAAAQAAABAAAAQgBAAAAABQgBAAgBAAQAAABgBgBQgBAAAAAAQgBAAAAAAQgBgBAAAAQgCgCAAgIQAEg5AHghQAAgGAEAAIADACQAHAIgEARQgDAhgCAZQgBAJADAGQACAEAAACQgBABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAIgCgBgAJLL3IgEgFIgGgDIgBgBQgDgCgBgDIAEgFIAGgIIAPghQAGgNAGgMIAdg5QACgEACAAQABAAABABQAAAAABAAQAAABAAAAQAAABAAABIgBAFIgLAZIABABQACAEgGAFIgEAFIgJAQIgMAZIgKAZQgHAOgJAHIANAMIgBAAQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBgBgAIXL4QAAAAAAAAQAAAAgBAAQAAAAAAgBQAAAAAAgBQgCgDADgIIAIgbQACgDAEABQACAAABAFIgBAGIACALQACAGgBAEIgCgEQgBgGgCgFQgFARgFAHIgDABIgBAAgAHWLqIBaheQAHgJACgFIACgEQAAAAABgBQAAAAABAAQAAAAABAAQAAAAABAAQAEABAAAEQAAACgCAEQhIBMgjAeQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBABgBgAHDLpQgDgCADgGIAAgKQABhIgDhBQAAAAAAgBQAAAAAAgBQABAAAAAAQAAAAABgBQAAAAAAAAQABABAAAAQABAAAAABQAAABAAAAIACAJIABACIADACQAEABgBAGIgCB+QAAAFgCADIgEACIgBAAIgCgBgAJPLmIAIgBIAAAAIAIAAIgBACIgPABgAHXLNIAAgCIAWgoQAAgBABAAQAAgBABAAQAAgBABAAQAAAAABAAIgZAuQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAgBgAEbLCIgCgEQgCgFAAgQQgCgMgGgaQgIgegPhRQgDgWAAgIQAAgFADgBQADgBACADIABAFQAHA6AUA1IAGAQQAEANADAXIAHAjQAAABgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAIgMg0QgIgegJgUQABALAEAQIAHAbQAEAPADAgIgBAEIgCACIgDgCgAE2LCIgBgEIAAgNQAAgEgBgBQgFAAgCgCQgCgBAAgEQgBgHACgKIADgRQACgOAAgVIgDgjQAAgNACgGQADgLABgGQgBgKACgEQABgEACAAQAEgBABAEIABAGIACApQACAcAAAOIgDAfQgBATACANQABAFgCACIgEABIgBADQgCALACALIgBAAIgDgBgAE+K0IABgBIAAgCIAAgBIAAgBIABAAIABAAIABAAIABAAIAAABIAAAAIAAABIgBADIgBADIgCABgAC/JmQgBgBABgGIARhDIACgJIACgEIAEgBQAAABABAAQAAAAABAAQAAAAAAABQAAAAABAAQAAgFACgCQAAAAABgBQAAAAABAAQAAAAABgBQAAAAABAAQABAAAAAAQABAAAAABQAAAAABAAQAAAAAAABQACACgDADIgIAWQgLAegBANQgCAGgDABIgDAKQgBAEgBABQgBAAAAABQAAAAgBAAQAAAAAAAAQgBAAAAAAIgDAAgADjJMIAAgBIgBABQAAAAgBAAQAAgBAAAAQAAAAAAgBQAAgBAAgBIAAgNIAAgFIABAAIABgVQAAgFABgDIACAAIgCAsIABAKIgCABIAAgEgABXI+QAAAAgBAAQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAgCABgGQADgHgBgKIgDgRQgBgGABgQQAAgOgCgHIgBgJQAAgGAFAAQAFAAACAHQAHAQADAPIAGgIIAFgLQAKgRAPgVIAFgFIAJgOQgEgBABgEQABgDADgDIAYgYQAGgHAHgEIAOgIIAWgKQAGgCADABQAEABgBAHIgFAIQgwA6gSAhQgSAhgKAkQgDALgCADQgEAHgJgBQgGgEgEABQgCABgFAFQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBAAAAQgFAFgBABIgDABIgCgBgAB2IhIAHAAIAAgBIgEAAIgBgBIgBgBgAAvIFQgFgEgCgNIgDgRIgHgaQgUhJgJgcQgBgEABgCQAAAAABAAQAAgBABAAQAAAAABABQABAAAAAAIAEAFIAOAqQARAtAEAaQAJgugMguIgbhVQgCgEACgCQADgDAFAGIAGANIADAQIAFAKIAEAJIACglQABgJAFABQADAAACAHQACALABAgIAABoQAJgLAJgVQALgZAEgIIAEgFQAEgCACADQACABgBAFQgDAIgKANIgQArQgQAtgCAVQAAAGgEAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAgBAAAAgAAdGyIAAABIAAABIABAEIABAAIgBgDIAAgCIgBgEgAkvFTQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQgBgDABgGIABgNIgBgNIgDgIQgBgEAAgGIAAgKIABgKQAAAAABgBQAAAAAAgBQABAAABAAQAAAAABgBQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQACgRAFghIAGgQQACgEABgBQAEgCADACQACABAAAEIgDAVIgDASIACANQABAIAAAFIAKgPIARgVIANgNIAGgCQADAAABACQAEADgFAGQgRAagMAOIgFAGIgPAaIgCAKQgBAOgFAFIgFAEIgDAEIgCAFQAAABAAAAQgBABAAAAQAAABgBAAQAAABgBAAIgCAAIgCAAgAkeEJIAAACIgBABIAAACIgBAHQAAAAAAgBQABAAAAAAQABgBAAAAQAAgBABgBIAAgIIAAgEIAAgCIgBAGgAOPEhQgBgGAAgHIABgBIADARQACAJABAFIgCABgAleEOIAChlQAAgFABgCQABAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQABAAAAAAQABAAAAAAQABAAAAAAQAAABABAAIAAAFIgIBxQgDgBAAgIgAmcDmQgDgMgBgQIgBgVQACgQAHgRIAEgBIACAEQgKAaADAYQABgHADgCQAAAAABAAQAAAAABgBQAAAAABAAQAAAAABAAQABABAAAAQABAAAAABQAAAAABAAQAAABgBAAQAAACgCADQgGAHADAIIAWgaIAGgFQAAAAABAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAAAQABABAAAAQAAABAAAAQAAAAAAABQABABgEAEQgUARgLAXQAAABgBAAQAAABAAAAQgBABAAAAQAAAAgBAAIgBAAQgCAAgBgFgAAADTIACgpQAAAAAAgBQAAgBAAAAQAAAAABAAQAAAAAAAAIgBAqQAAABgBABQAAAAAAABQAAAAAAAAQgBABAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBgAF8C7IADggQAAgBAAgBQAAAAABgBQAAAAAAAAQABAAAAAAIgCAmQAAABAAAAQAAAAAAABQgBAAAAAAQAAAAgBAAIgBgFgAnbCzIgDgVQgEAIgEgBQgFgBAAgIIgCgoQgBgOACgGQACgCACADQACADAAADQABAUAAARQgBAEADABQADgHgBgLIABgSIACgKQABgFADAAQAFgBgCAJIgDAcIAPgTQABAAAAAAQABABAAAAQABAAAAABQAAABABAAQAAADAAADQgCAEgGAGIgHAKQgCAGABAMIADAdIgDACQgDgCgBgIgAiECEIgMgxIACAAIAMAuQAAABAAAAQAAABAAAAQAAABgBAAQAAAAAAAAIgBAAgAoPB1QgFgBABgKIAChMQAAgGACgCQAAAAABgBQAAAAAAAAQABAAAAgBQABAAAAAAQABAAABAAQAAAAABABQAAAAAAAAQABAAAAABQACgFAFgDQAEAGgBAIIgCAOQgEALgBAYIgBAcQAAAGgBADQgDAEgDAAIgCgBgABbBdIAEghQABAAAAgBQAAgBABAAQAAAAAAgBQABAAAAAAIgGAnIgCADIABgGgApbBTQgDgCAAgGIgEg6QgCgOADgHQAAgBABAAQAAgBAAAAQABgBAAAAQABAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAABQACACABAFQAHAogBAmQAAAEgCACIgDACQgDAAgBgEgApFBMIADgbQAAAAAAgBQAAAAAAAAQAAAAABgBQAAAAAAAAIACACIgBAGIgDAVQAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAgBgAqXAzQgEgBAAgJQABgJgGgQQgFgQAAgJIgDAbQgCgGABgJIACgOQAAgJgBgJQgGghAAgVQAAgSgBgFIgBgGQAAgEAEgCQAEgBADAGIAEAJIAFAGQAEAFgCAMIAAARIAGBBQAFgZAMgkIANgpQAHgRgBgNIABgIQACgEAHgDQAFAEgDALQgNAugCARQgCAPgBAdIAcg0QACgEACgBQADgDADADQACACgCAGQgxBcgQAbQgCAFgDAAIgBAAgAqMAIQgBAEgBAAIgDABIgBACIgBAHQAAAAAAABQAAAAAAABQAAAAAAAAQAAAAAAAAQABABAAAAQABAAAAAAQABAAAAgBQAAgBABgBIANgnQADgKgBgFQgHARgFAXgArxgjQgEgBgBgDQgBgFACgJQAEgSgBgcIgBgvQAAAAAAgBQAAgBAAAAQAAgBAAAAQABgBAAAAQACgBADADQACAEAAAIIAABPQAFgHAHgRQAGgQAGgHQAEgEADABQAEABgBAFQAAACgEAFQgSAZgJAdIgCAFIgEABIgDgBgAmSipIgbhWQgEgMgEgEIgEgEQgCgDADgCQACgCADADQAHAFAHARQAPAxAiCDQABAGgCACgAjVhnIAUhIQABgGAEABIgaBhQgBAEgDACQACgMADgOgAsWhwIAAg2QgBgGAEgBQADgBACAEQABADAAADIgBAfQgBAKABAIIABAHQgBAEgEAAQgEAAAAgIgAsMh/QgBAAAAAAQAAgBAAAAQAAAAABgBQAAAAAAAAIAEgGIADgCIABgCIABAAQgCAFgGAHgAstihIACgJIACgFIADgJIAGgIQADgCACADQACACgEAGIgEALQgEAFgBAGIgBAEIgDABQgDAAAAgFgAsyisQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBIACgFIABgIQAAgRgBgFQgCgGgDgFIACgDIAEgBQADABABAHIACAIQADgCACgFQACgFADAAQAAAAABAAQAAABABAAQAAABAAAAQAAAAABABIgBAEIgFAHIgDAHIgFAWIgCAGIgDABIgBAAgAtHj2QgCgEACgGIAMgmIACgGQAAAAABgBQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgFAMIgFAiQgCAEgCABIAFgdIgCAHQgFAOgBALgAtDlUIAAgDIABgCIABgDIADgFIADgBIgDAFIgEAIIgBACIAAgBgAtTlYIACgEIADgOIACgFIAAgCIACgBIABABQgCAGgCAMIgDAKIgCAAgAtWlaIAAgDIABgDIAAgBIABgCIABgBIgCAMIgBABQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAgAtdlhIAHgSIABgCIABAAIAAADIgBACIgCAFIgDAHIgBACIgBACIgBgBgAtWloIADgDIABgBIADAAIgBACIgDABIgCACIgDACQAAgBAAAAQAAAAAAgBQABAAAAgBQAAAAABAAgAiZmJIAAgoIACAAIAAAkIAAADIgBABIgBAAgAtpmfIAUghIABAAQgCAHgIALIgKASIgDACQgBgCADgDgAtrnbQgEgCAAgIIAEgfQADgVABgLQgBgDACgCQAAAAABAAQAAAAAAgBQABAAAAAAQABAAAAAAQABAAABABQAAAAABAAQAAAAAAABQABAAAAAAQACACAAAGQgBAGABADIACAFIAAAFQAAABAAAAQAAAAAAABQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAgBAAAAQgBAEABAJQAAAIgBAEIgEALIgBAIQgCAFgEAAIgBAAgAt5pYQgDAAgEgGIgSgrIgBgIQAAgFAEABQAKAIAGANQAAgDAHgCQABgCAAgEIADgRQABgJAFAAQADABABAEIACAGQAHABABADQAAACgDAEQgHAJgCAOQALgJAPgJQAFgDADAAQAFAAABAFQgMAIgSATIgRATQgDADgDAAIAAAAgAtyrMIAAgBIABAAIAAgBIACABIAJACIAAACIgMgDgAtmrcQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAAAQABgBAAAAQABAAAAAAQgGgEgBgRQgBgPgEgKQAAgBAAAAQAAAAAAgBQAAAAABgBQAAAAABAAQABAAAAAAQABgBAAAAQABAAAAABQABAAAAAAQADACABAFIAIAeQALgKAFgIIAFgEQAFgBABADQgBADgCACQgNANgHARIgCADQAAABgBAAQgBABAAAAQgBAAAAAAQgBAAAAAAIgCABQgDAAgBgDg");
	this.shape_3.setTransform(844.85,791.7611);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	// Layer_7
	this.instance_23 = new lib.CachedBmp_30();
	this.instance_23.setTransform(394.85,627.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(1));

	// Layer_27
	this.instance_24 = new lib.CachedBmp_31();
	this.instance_24.setTransform(394.35,630.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(1));

	// Layer_26
	this.instance_25 = new lib.CachedBmp_32();
	this.instance_25.setTransform(324.5,635.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(1));

	// Layer_25
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#7F9C2D").s().p("AAHGbQgTguAAgxQAAgBAAgBQAAgBAAAAQABgBAAAAQAAAAABAAIABACQADALAEAcQADAgALAfQgDAAgCgFgAt/GRIAAgDIgCgHIgLgVIgOgXIgUghIgNgSQgBAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAIADACQAHAFAKAPQARAbARAjQAIAOABAHQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIgCACIgCgBgAyjGHQgRgogZggQgEgFACgCQABgBAAAAQABAAABAAQAAAAABAAQAAAAABAAIAEAEQAaAjAOAoQABAAAAABQAAABAAAAQAAABAAAAQAAABgBAAIgBABQgCAAgCgEgAxDF4IgDgGIgGgDQgBgBgDgKQgBgGgHgMIgqhFIgBgEQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAKAMAPAZQAPAaAKALQgDgogDgQQgEgfgJgXQgDgIAEgDQAEgBACACIAEAHQANAsAGBOQAPgwAdgrQADgEACAAQAFAAAAAFQAAADgDAEQgRAhgIAUQgLAegDAbQAAAIgFAAQgCAAgDgDgAjJFjIAYg4QACgEACAAQAAAAAAAAQAAABAAAAQAAABAAABQAAAAAAABIgYA5QgCAEgCAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAgBAAgBgAoNFiIAAgGQAHgjAogyQAEgEACACQACACgDADQghAngNAvIgBADIgCABQAAAAgBAAQAAAAgBgBQAAAAAAAAQgBgBAAAAgAjzFYQgDgJgFgjQgEgbgIgQIgDgIQAFgCADAFQADACABAFQANAqABAqQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAgAtMFJIgCgiIgDgTIABgMQAEgfAQgVIADgDQAAAAABAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAQAAAAAAABQAAAAAAABQgBAAAAABQgQAYgEAmQgBAWADAsQAAAAAAABQAAABAAAAQgBAAAAABQAAAAgBAAgACqD4IgNgjQgBgDABgCQACgDAEADIADAFIAPAqQAJAYACAPIACAUIAEAZIgCAAQgOg+gMgdgAqIFJQgTg8gZg1QgIgRAAgHQgBgHAEgBQADgBAEAFIAPAYQAEAFADALQAKAaAOA2QAEgpAFgWQAIgjAOgZIAEgFQAEgCACACQADADgDAHQgLARgFAPIgGAYQgJAtgCAlQAAAJgFAAIgBAAQgEAAgCgIgAqkDmIACAFIgGgSQgBgEgDgCgAl6FAIgOg4QgBgHABgDQAAAAAAgBQABAAAAAAQAAgBAAAAQABAAAAAAIACACQAHAaABAHIADAUIADAJQABAFgBADIgBAAQgCAAgBgEgAFnEfIARgnQACgFADgCIgeBFQgCAGgDADIANgggAJAE1QgFABgEgFIgEAIQgBgDADgIQABgHgGgMQgOgcgJgfQgDgIAFgCQAFgDAEAIQAFAIAFAVQAEATAHAJIgDhMIADg3QAAgFADgBQADgBACAEIACAFIABAGIgBAFIgCALQgCAsADAmQAKgaAQgWIAKgMQADgFADAAQADABAAADQABABgCAEIgLAOQgFAFgHANQgLAWgGAQQgCAHAAAGIACAMIADAQIABAHQgBAEgEAAQgEAAgBgIgABFEJIAAgIQAAgFACAAQABgBABAAQAAAAABABQAAAAAAAAQABABAAABIAAAEIgFA2IgBAFQgBgRABgjgAMHDcQADgFACABQACABgBAFQgLAcgGAjIgDAWQgBguAPgpgAOJEfIgCgCQgGgOgPgWIgHAXIAHANQgDABgDgCIgDgFIAAAAQgBAEgDAAQgBAAAAAAQgBAAAAgBQAAAAAAgBQgBgBAAgBIACgFIABgCQgGgNgIgZQgKgdgIgOIgCgFQAAgEADgBQADAAADAEQAUAZARAXQAFgRAHgQIAIgNQABAAAAAAQABgBAAAAQAAAAABAAQAAAAABAAQABAAAAAAQAAAAABABQAAAAAAABQAAAAAAABIgCAFQgKAPgIAaIgCAFIALAQIAJAPIACADQAHgaALgbQAIgUAGgKIALgPQABgBABAAQAAgBABAAQAAAAABgBQAAAAAAAAQAEABgBAFQAAACgDADQgJAJgIARIgYBGQgBAFgBABQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAIgCgBgANoEHIABgGIAFgOIgLgPIgNgTQAJAdAJAZgAQbESQADgqgBguIAAgEIgBgCIgIgSQAAgBAAAAQgBgBAAAAQAAAAABgBQAAAAAAAAIACgBQADABACAGQAGANAMANIAXAXQAbAXAPAFQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAgBgBQgOgDgQgLQgMgJgNgNIgSgSQACAugHAtIgBgFgAw/D0IgDgDQgCgEAAgDQABgKAJgCQAJgBAEAIQACAEgBAEQgBAEgDADQgEADgEAAQgDAAgEgDgAS2DoQgDgIAEgOIAOgsQADgJADgHQAFgMANgVIALgPQABAAABgBQAAAAABgBQAAAAABAAQAAAAAAAAQABAAABAAQABAAAAAAQABAAAAABQAAAAAAABIgCAEQgGAGgKAQIgOAaIgXA/IgCAJQAAAGADADIgCAAQAAAAAAAAQgBAAAAgBQAAAAgBgBQAAAAAAgBgAnYCqIAFgVQAJgfAJgOQAEgIALgOQAHgKAHgDQAAACgDADQgIAIgJAPQgKAPgDAHIgGARQgQA2ACAdQABAEgCACQgDgeAFgZgAGNDTIAGgSIAGgRQAKgZAWgQQgCAGgLAKQgLANgIAUQgFAMgHAZQgCgEACgGgAikDXIgBgDQgHgMgJgfQgJgcgIgPIgLgSQgEgIADgFQADgDACADIABADQAAAFADAGIAHALQAHALAJAcIAMArQACAHACACIABADIgBABIgCAAgAn5DDQgKgrgnhAQgNgTgHgHIABAAIABABQANANARAcQATAfAMAjQAGAOACANIAAAAIgCgCgAijDAQAJhJACglIAAgGQACgEACgBQABABAAAAQABABAAAAQAAABAAAAQAAABAAABIgBAFQgDAMgDAZIgIBNQAAAAgBAAQAAgBAAAAQAAAAgBgBQAAAAAAgBgAMmCPQgCgFAFgKIAMgYQAHgQAJgQQATgiAegdIACgBQABAAAAAAQABAAAAAAQAAAAAAABQAAAAAAAAQABAAAAABQAAAAAAAAQAAAAgBABQAAAAgBAAQgmArgWAsIgMAWQgJAQABAIIADAAIgBACIgCABIgDgEgAlHAeIAGgrQAEgagBgSQAAgBABgBQAAgBAAAAQAAgBABAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABQAFAQgIAkQgMA/ACBCQAAAEgDAAQgChEAEgdgAqvAdQgVgggchGIgDgMQADAAACAFIAYA4QAOAhAMAVQAEAHAFABIgBABQgFgCgGgIgAjQgnIADgBQADAKAAARIACAaQAAAGgDABIgFg7gAn1gCIgEgNIgUgvIgQgaQgKgQgGgFQABAAAAAAQAAgBABAAQAAAAAAABQABAAAAABQAMAMAPAZIAGAJIAKAUQAOAeAFAQQAAABAAAAQAAABAAABQgBAAAAAAQAAABgBAAQgEgEgDgGgAwWg+IgDgCQgHgJgDgGIgEgRIgFgoQgFgkgGgRQgHgTAAgEQABAAAAAAQAAAAAAAAQABAAAAABQAAAAAAABQAKARAEAOIAEARQAGAjACAaQABAOACAHQAFAMAHAFQAAAAAAABQAAAAAAAAQAAABAAAAQgBAAAAAAIgCgBgAvGhdQgBAAAAAAQgBAAAAgBQAAAAAAgBQgBgBAAgBIgCg0QAAgBAAgBQAAAAAAgBQABAAAAAAQAAgBABAAQADAAAAAFIACAzQAAABAAABQAAABAAAAQAAABgBAAQAAAAgBAAIAAAAgAu8hkIgBgSQAEg0AEgZIAEgTIAGgSQAJgaAMgIQAEgDACACIgOATIgHAOIgHAaQgFAXgFAuIgCATIAAAQQABAGgBACIgBAAQgCAAgBgEgAvxh7QgDgBgEgHQgEgMAAgcQgBgTAFgKQADgIAFgCIgFANQgCAGgBATQAAAiAGAOQAFAAADgEQAAABAAAAQAAABAAABQgBAAAAAAQAAABgBAAIgDACIgCgBgAxviIIgDgKIgIgOQgDgEgEgSQAAAAAAAAQgBgBABAAQAAgBAAAAQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAIABADQAMAdAHAZIAAACQgDgEgCgGgAnziqQgJgSgGgUQgFgTgHgHQAAAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAABgBQAAgBAAAAQABAAAAgBQABAAABAAQADABADAFQAFAKAHAZQAGAXAHALQgEAAgCgFgAzgisIgHgzQgDgRgEgFQgDgGACgBQABgBAAAAQABAAABAAQAAAAABABQAAAAABAAQAEAEABAKIAIBJQgCgCgBgFgAx0i9QgDgEgDgJIgWhAQgBgEACgCQAAAAABAAQAAgBABAAQABAAAAABQABAAAAAAIADAFQAFAKAMAuQAFASAHAHIgCAAQgDAAgEgDgApejgIgDgHIgRg6IgFgLIgEgJQgCgGgEgCIgFgGQABgEAFABQACAAADADQAGAGADAGIARArQgBgkAMgsQABgFACgCQAFgEADAEQABACgBAEIgEALQgDAKgBAMIgDAXIAAA+QABAGgBACQgBAAAAAAQAAABgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAgBAAQAAAAgBgBQAAAAgBgBgAjUjmQgCAAgDgFQgFgLAAgVIAAgnQgBgIACgHQACgIAHgDIAEgBQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQAAABgFAFQgDADAAAIIgBAzQAAATAEAIQADgCABgEQACAEgCAEQgDADgCAAIgBAAgAzOk4IAAgHIgCgHIgDgaIgIgOQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAABgBQAAgBAAAAQAAgBABAAQAAAAAAAAQADgBABAEIADAFIgBgVQgBgSAEgIQABgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQADAAAAAFQgCAWADAmIAAACQABAAAAAAQAAAAABAAQAAAAAAAAQABABAAAAIAAACQAFAHAEAEIASANQAAAAgBAAQAAAAgBAAQgBAAAAAAQgBgBgBAAIgKgIIgMgHIgBAOIABACQAEAGAFgCQgGAEgEgCIgBACQAAABAAABQAAAAAAABQAAAAgBABQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBgAywlEIgUgcIABAAIABABIAVAdIAAAAIgDgCgAy/lpIACAAIASAiIgBABQgLgSgIgRgAyplTIARgmQABAAAAgBQAAAAABAAQAAgBAAAAQABAAAAABIgTAog");
	this.shape_4.setTransform(446.06,723.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(0,255,209,0.2)").s().p("AANDuIgWgEIgGgBIgdgFIgkgBQgVgCgLgJIgCAAQgSgOgEgbIgBgJIgBgnQAAgFgCgCQgCgCgGgBQgKgBgJgHIgIgGQgfgagCgmQgCgTAHgRQAIgRAOgMQgHAAgXAHIgGACQgOADgJgEQgLgFgCgPQgCgNAIgLQAEgHAJgGQALgIARgHQgKgJgDgNQgEgNAFgMQAEgMALgHQALgIANAAQgGgPAHgQQAGgQAOgHQATgJAXAJQAVAGAPASQAPARAFAVQALgDADgOIACgMIACgMQADgNAHgKQAHgHAKgFQAHgEAHgBIAHAAQAMAAAKAGQAKAHARATIAUATQAKAMgBALQAIgGAKgCIAKAAQAQAAAMAJQAMAKAEAPIACAIIAAAHQAAAHgDAHQAHAHAFAHIAKADIALAEIAhAOQAPAGAEADQAMAJACAMQABAPgLAIQgGAEgMABQgOACgJgCQgEgCgPgJIgNgHIgEAFIgFAEQgJAFgBAEQgCAEACAIIABABIALAcIACAHQAGAXgHAQIgIAMQgGAHgCAFQgEAHgCAQQgBARgDAGQgEAMgMAKQgHAGgQAJQgQAJgGAIQgFAHgHAPQgLAQgXADIgNABIgGAAg");
	this.shape_5.setTransform(241.7126,623.9832);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(0,172,204,0.2)").s().p("AgmD8IgGgBQgJgBgIgFQgLgHgGgLQgFgKAAgKQAMAIAVACIAkACIAcAFIAGABIgJAHQgOAMgLAEQgKAEgKAAIgEAAgAhuCPQgBgPgCgDQgCgDgMgKQgFgEgFgIQAJAGAKACQAGABACACQACACAAAFIABAnQgDgHAAgHgAi7gbIAGgBQAXgIAHABQgOALgIASQgIgJgGgMgAC2gNQgCgHACgFQABgDAJgGIgJAXIgBgCgAjNh2QABgSAEgNQADgJAEgHQAPgZAYgBQgDgJAEgKIADgHQAIgNAOgEQAWgIAhAOQAPAHAJAIQAGAFAEAGIAEgHQAFgHAKgFIASgIQgHAJgDANIgCAMIgCAMQgDAOgLAEQgFgWgPgRQgPgRgVgHQgXgIgTAJQgOAGgGAQQgHAQAGAPQgNAAgLAIQgLAIgEAMQgFAMAEANQADANAKAIQgSAIgLAHQgCgQACgRgADFhnQgFgHgHgHQADgHAAgIIACACIAAAAQAJAJAEAHQADAGABAIIgKgDgABpjEIgUgSQgRgUgKgGQgKgGgMgBIgIABIAGgDQATgGASANQASAMABAUQAEAAAEACQAGAEAGAGIAQAOIADADIADABQgKACgIAFQABgLgKgMg");
	this.shape_6.setTransform(238.7419,624.9258);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(0,121,47,0.2)").s().p("AgNDxQgQgCgNgPIAFABQANABALgFQALgEAOgMIAJgHIAYAEQAKAAAIgBQgKANgUANQgZAOgQAAIgFAAgAC4gmIAKgXIAEgEIACATQAAAPgFAVIgLgcgAC+ifIgBgGIACAIIgBgCgAjEjEQAEgMALgHQASgIAGgGIAFgIQgEAKAEAJQgZABgPAZQgEAHgCAJQgCgKAEgKgABwjhQgHgHgFgDQANAGAJALIAFAHIgPgOgAgvjwIAKADIADABIgEAHQgDgGgGgFg");
	this.shape_7.setTransform(238.5994,627.647);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4}]}).wait(1));

	// ground
	this.instance_26 = new lib.CachedBmp_34();
	this.instance_26.setTransform(194.9,528.6,0.5,0.5);

	this.instance_27 = new lib.CachedBmp_33();
	this.instance_27.setTransform(340.45,759.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_27},{t:this.instance_26}]}).wait(1));

	// MergedLayer_6
	this.instance_28 = new lib.CachedBmp_36();
	this.instance_28.setTransform(366.9,-134.2,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_35();
	this.instance_29.setTransform(650.3,905.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_29},{t:this.instance_28}]}).wait(1));

	// Layer_5
	this.instance_30 = new lib.bush("synched",0);
	this.instance_30.setTransform(234.85,622.55,1,1,0,0,0,36.1,26.8);

	this.instance_31 = new lib.CachedBmp_38();
	this.instance_31.setTransform(112.25,483.9,0.5,0.5);

	this.instance_32 = new lib.CachedBmp_37();
	this.instance_32.setTransform(191.15,598.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_32},{t:this.instance_31},{t:this.instance_30}]}).wait(1));

	// Layer_5_copy
	this.instance_33 = new lib.bush("synched",0);
	this.instance_33.setTransform(234.85,622.55,1,1,0,0,0,36.1,26.8);

	this.instance_34 = new lib.CachedBmp_40();
	this.instance_34.setTransform(152.35,578.7,0.5,0.5);

	this.instance_35 = new lib.CachedBmp_39();
	this.instance_35.setTransform(191.15,610.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_35},{t:this.instance_34},{t:this.instance_33}]}).wait(1));

	// SUn
	this.instance_36 = new lib.SUn("synched",0);
	this.instance_36.setTransform(168.3,83.3,0.2682,0.2732,0,0,0,118,178.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_36).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(449.7,-195.6,1196.8,1364.1);
// library properties:
lib.properties = {
	id: '08F22967A20642048E6ABF82856494C2',
	width: 1536,
	height: 868,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/CachedBmp_44.png?1707772105536", id:"CachedBmp_44"},
		{src:"images/CachedBmp_43.png?1707772105536", id:"CachedBmp_43"},
		{src:"images/CachedBmp_38.png?1707772105536", id:"CachedBmp_38"},
		{src:"images/CachedBmp_34.png?1707772105536", id:"CachedBmp_34"},
		{src:"images/CachedBmp_20.png?1707772105536", id:"CachedBmp_20"},
		{src:"images/backgroud_1_atlas_1.png?1707772105316", id:"backgroud_1_atlas_1"},
		{src:"images/backgroud_1_atlas_2.png?1707772105316", id:"backgroud_1_atlas_2"},
		{src:"images/backgroud_1_atlas_3.png?1707772105316", id:"backgroud_1_atlas_3"},
		{src:"images/backgroud_1_atlas_4.png?1707772105316", id:"backgroud_1_atlas_4"},
		{src:"images/backgroud_1_atlas_5.png?1707772105317", id:"backgroud_1_atlas_5"},
		{src:"images/backgroud_1_atlas_6.png?1707772105317", id:"backgroud_1_atlas_6"},
		{src:"images/backgroud_1_atlas_7.png?1707772105317", id:"backgroud_1_atlas_7"},
		{src:"images/backgroud_1_atlas_8.png?1707772105317", id:"backgroud_1_atlas_8"},
		{src:"images/backgroud_1_atlas_9.png?1707772105319", id:"backgroud_1_atlas_9"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['08F22967A20642048E6ABF82856494C2'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;